package uk.ac.tees.mad.musicity.screens.splash

import android.window.SplashScreen
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import androidx.navigation.NavHostController

@Composable
fun SplashScreen(navController: NavHostController) {

}