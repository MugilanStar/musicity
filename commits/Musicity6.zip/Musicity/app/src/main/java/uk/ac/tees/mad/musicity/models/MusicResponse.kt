package uk.ac.tees.mad.musicity.models

data class MusicResponse(
    val `data`: List<Data>
)